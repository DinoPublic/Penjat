<!DOCTYPE html>
<html lang="es">
    <head>
        <?php echo $__env->make('layouts.shared/head-css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
    </head>
    <body class="loading_">
        <div id="wrapper">
            <?php echo $__env->make('layouts.shared/topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>    
            <div class="content-page">
                <div class="content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>  
            </div>    
        </div>          
        <?php echo $__env->make('layouts.shared/footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
        <?php echo $__env->yieldContent('scripts'); ?> 
    </body>
</html><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/layouts/vertical.blade.php ENDPATH**/ ?>