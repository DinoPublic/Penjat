<div class="card_player card_player_<?php echo e($jug['id']); ?> <?php if(!$current_player): ?> d-none <?php endif; ?>">
	<div class="row row_to_player">
		<div class="col-12 col_to_player">
			<div class="card p-3">
        		<div class="row text-center">
        			<div class="col-12 col-md-4">
        				<div class="block_jugador">
                			<img id="img_no_perfil_<?php echo e($jug['id']); ?>" src="<?php echo e($jug['foto']); ?>" class="img_no_perfil" />  
                			<span class="d-block mt-3">Jugador <?php echo e($jug['id']); ?></span>
    						<h3 class="mb-0"><b><?php echo e($jug['name']); ?></b></h3>              			
                		</div>	
        			</div>
        			<div class="col-12 col-md-4">
        				<div class="zona_ahorcado_dib">
        					<img class="img_hierba img_zona_ahorcado_dib <?php if($jug['trys'] >= 5): ?> d-none <?php endif; ?>" data-position="4" src="/img/ahorcado/0hierba.png" />
        					<img class="img_arbol img_zona_ahorcado_dib <?php if($jug['trys'] >= 4): ?> d-none <?php endif; ?>" data-position="3" src="/img/ahorcado/arbol.png" />
        					<img class="img_nudo img_zona_ahorcado_dib <?php if($jug['trys'] >= 3): ?> d-none <?php endif; ?>" data-position="2" src="/img/ahorcado/nudo.png" />
        					<img class="img_sol img_zona_ahorcado_dib <?php if($jug['trys'] >= 2): ?> d-none <?php endif; ?>" data-position="1" src="/img/ahorcado/sol.png" />
        					<img class="img_ahorcado img_zona_ahorcado_dib <?php if($jug['trys'] >= 1): ?> d-none <?php endif; ?>" data-position="0" src="/img/ahorcado/ahorcado.png" />
        				</div>        				
        			</div>
        			<div class="col-12 col-md-4">
        				<p class="intentos_text">Intents restants:</p>
        				<div class="intentos"><?php echo e($jug['trys']); ?></div>
        			</div>      		
    			</div>
        	</div>
		</div>
		<div class="col-12 text-center">
			<div class="zona_ahorcado mt-5 mb-5">
				<?php $__currentLoopData = $jug["word_keygen"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $in=>$it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="letter letter_<?php echo e($it['type']); ?> letter_<?php echo e($in); ?>">
						<?php if($it['type'] != 'inactive_char'): ?>
							<?php echo e($it['char']); ?>

						<?php endif; ?>						
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="col-12 text-center">
			<div class="zona_abc p-3 mt-3">
				<?php $__currentLoopData = $jug['abc']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ind_let => $let): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="abc_let abc_let_<?php echo e($let); ?> abc_let_<?php echo e($ind_let); ?> <?php if($let != 0): ?> abc_let_desactivated <?php endif; ?> <?php if($jug['trys'] == 0): ?> abc_let_desactivated <?php endif; ?>" data-id-jugador="<?php echo e($jug['id']); ?>"><?php echo e($ind_let); ?></div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
		</div>
		<div class="col-12 text-end mb-2">
			<button class="btn btn_continue_gaming <?php echo e($jug['btn']); ?> <?php if($jug['trys'] > 0 && $jug['status'] == 0): ?> d-none <?php endif; ?>" data-next-jug="<?php echo e($next_jug); ?>">Continuar</button>
		</div>
	</div>	
</div><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/parts/part2_jugador.blade.php ENDPATH**/ ?>