<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="/js/bootstrap.min.js"></script>
<script src="/js/0main.js?a=<?php echo strtotime("now"); ?>"></script>

<?php echo $__env->yieldContent('script'); ?>

<?php echo $__env->yieldContent('script-bottom'); ?><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/layouts/shared/footer-script.blade.php ENDPATH**/ ?>