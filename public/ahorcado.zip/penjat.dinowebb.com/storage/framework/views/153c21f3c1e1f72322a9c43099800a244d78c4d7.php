<div class="card p-3">
	<div class="row text-center">
		<div class="col-12">
			<?php if(count($array_jugadores['ganadores']) == 0): ?>
				<p class="msg_felicitats">
					El déu de les mentides us ha impedit la victòria, <br>millor sort la propera vegada
				</p>
				<img class="img-fluid mb-2" src="/img/loki.gif" />
			<?php else: ?>
				<p class="msg_felicitats">SUPER HEROIS GUANAYADORS</p>
				<?php $__currentLoopData = $array_jugadores['ganadores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="jug_ganador animate__animated animate__bounce animate__infinite">
						<img src="<?php echo e($jug['foto']); ?>" class="" />
						<small><b>Jugador <?php echo e($jug['id']); ?></b></small><br>
						<p><?php echo e($jug['name']); ?></p>
						<div class="barra_vida_100">
							<small class="vida_text">VIDA</small>
							<small class="vida_val">100/100</small>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php if(count($array_jugadores['perdedores']) > 0): ?>
					<p class="msg_felicitats mt-3">VS</p>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<div class="col-12 mt-1 mb-2">
			<?php if(count($array_jugadores['perdedores']) > 0): ?>
				<?php $__currentLoopData = $array_jugadores['perdedores']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jug): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="jug_perdedor animate__animated animate__rollIn">
						<img src="<?php echo e($jug['foto']); ?>" class="" />
						<p><?php echo e($jug['name']); ?></p>
						<div class="barra_vida_0">
							<small class="vida_text">VIDA</small>
							<small class="vida_val">0/100</small>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php endif; ?>
		</div>
		<div class="col-12 mt-5">
			<div class="row">
				<div class="col-6">
					<a href="/game/reiniciar?type=comenzar" class="btn btn_reiniciar_juego">Revenja</a>
				</div>
				<div class="col-6">
					<a href="/game/reiniciar?type=comenzar_nuevo" class="btn btn_comenzar_nuevo">Nova partida</a>
				</div>
			</div>
		</div>
	</div>
</div><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/parts/part3_jugador.blade.php ENDPATH**/ ?>