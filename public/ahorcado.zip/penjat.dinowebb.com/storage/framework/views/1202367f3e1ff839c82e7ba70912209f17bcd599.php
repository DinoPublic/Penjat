<?php $__currentLoopData = range(1, $num_jugadors); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<div class="col-6 col-lg-2">					
		<div class="block_jugador block_jugador_1" data-id-jugador="<?php echo e($i); ?>">
			<img id="img_no_perfil_<?php echo e($i); ?>" src="/img/no.jpg" class="img_no_perfil" data-id-jugador="<?php echo e($i); ?>" data-foto="0" />
			<button class="btn btn_cambiar_foto_perfil" data-id-jugador="<?php echo e($i); ?>">Cambiar foto</button>
			<span class="d-block">Jugador <?php echo e($i); ?></span>
			<input type="text" id="name_jugador_<?php echo e($i); ?>" class="form-control name_jugador" />
		</div>					
	</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/parts/part1_jugador.blade.php ENDPATH**/ ?>