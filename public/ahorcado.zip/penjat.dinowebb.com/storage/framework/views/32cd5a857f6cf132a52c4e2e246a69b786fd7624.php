<div class="navbar-custom">
    <div class="container-fluid">
    	<div class="row">
    		<div class="col-12">
    			<h1>Penjat Edició Marvel</h1>
    		</div>
    	</div>
    </div>
</div><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/layouts/shared/topbar.blade.php ENDPATH**/ ?>