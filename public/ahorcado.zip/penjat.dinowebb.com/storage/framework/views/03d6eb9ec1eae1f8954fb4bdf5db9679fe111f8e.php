<div id="container_start_2" class="container container_start mt-2 mb-2 <?php if($array_data['juego_empezado'] != 1): ?> d-none <?php endif; ?>">
	<?php echo $html_game_paso2; ?>

</div><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/parts/part2.blade.php ENDPATH**/ ?>