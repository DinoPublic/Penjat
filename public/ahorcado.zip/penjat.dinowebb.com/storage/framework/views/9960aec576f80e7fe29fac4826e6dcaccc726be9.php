<div id="container_start_3" class="container container_start mt-2 mb-2 <?php if($array_data['juego_empezado'] != 2): ?> d-none <?php endif; ?>">
	<?php echo $html_game_paso3; ?>

</div><?php /**PATH /var/www/vhosts/dinowebb.com/penjat.dinowebb.com/resources/views/parts/part3.blade.php ENDPATH**/ ?>